function Admin (){

return(
    <h1>Vida Boa</h1>
);

}
export default Admin;