import './assets/styles/custom.scss';
import './App.css';
import BRoutes from 'Routes';

function App() {
  return (
    <BRoutes />
  );
}

export default App;